package org.example.dant_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DantBeApplication {
    public static void main(String[] args) {
        SpringApplication.run(DantBeApplication.class, args);
    }

}
