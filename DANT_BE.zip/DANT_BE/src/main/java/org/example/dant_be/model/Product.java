package org.example.dant_be.model;

public class Product {
}
