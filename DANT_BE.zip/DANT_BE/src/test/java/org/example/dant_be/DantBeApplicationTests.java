package org.example.dant_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DantBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
